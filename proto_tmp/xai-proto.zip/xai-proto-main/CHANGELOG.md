# Changelog

## [Unreleased]
### Added
- New features or functionalities added to the project.

### Changed
- Updates or modifications to existing features.

### Fixed
- Bug fixes or corrections to existing issues.

### Removed
- Features or functionalities that have been removed.

## [v1.0.0](https://github.com/xai-org/xai-proto/releases/tag/v1.0.0) - 2025-06-30
### Added
- Initial v1.0.0 release of the public protobuf definitions for xAI's gRPC based APIs
